
document.addEventListener("DOMContentLoaded", () => {
  const board = document.getElementById("board");
  let boardTitle = document.getElementById("board-title");
  const urlParams = new URLSearchParams(window.location.search);
  let boardParam = urlParams.get("board") || "Default";
  let currentTool = 'cursor';

  if (!boardTitle) {
    boardTitle = document.createElement("h1");
    boardTitle.id = "board-title";
    document.body.appendChild(boardTitle);
  }
  boardTitle.contentEditable = true;
  boardTitle.textContent = boardParam;
  document.title = boardParam;

  const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
  const applyDarkMode = (e) => document.body.classList.toggle('dark-mode', e.matches);
  applyDarkMode(darkModeQuery);
  darkModeQuery.addListener(applyDarkMode);

  // Tools
  const tools = {
      'tool-cursor': 'cursor',
      'tool-text': 'text',
      'tool-image': 'image',
      'tool-pen': 'pen',
      'tool-eraser': 'eraser'
  };

  Object.keys(tools).forEach(id => {
      const el = document.getElementById(id);
      if(el) {
          el.addEventListener('click', (e) => {
              if (tools[id] === 'image') {
                  document.getElementById('img-upload').click();
                  return;
              }
              currentTool = tools[id];
              document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
              document.getElementById(id).classList.add('active');
              
              if (currentTool === 'eraser') {
                  document.body.classList.add('eraser-mode');
                  board.style.cursor = 'cell';
              } else {
                  document.body.classList.remove('eraser-mode');
                  board.style.cursor = currentTool === 'cursor' ? 'default' : 
                                       currentTool === 'text' ? 'text' : 'crosshair';
              }
              document.querySelectorAll('.item').forEach(el => {
                   if (currentTool !== 'eraser') {
                      el.style.pointerEvents = (currentTool === 'cursor') ? 'auto' : 'none';
                   }
              });
          });
      }
  });
  
  // EXPORT
  document.getElementById('tool-export').addEventListener('click', () => {
      chrome.storage.local.get({ boards: {} }, r => {
          const data = r.boards[boardParam] || [];
          const json = JSON.stringify({ title: boardParam, items: data });
          const blob = new Blob([json], { type: "application/json" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          // REBRAND Export Name
          a.download = `Mindframe - ${boardParam}.json`;
          a.click();
          URL.revokeObjectURL(url);
      });
  });

  // IMPORT
  const importInput = document.getElementById('file-import');
  document.getElementById('tool-import').addEventListener('click', () => {
      importInput.click();
  });

  importInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (ev) => {
          try {
              const data = JSON.parse(ev.target.result);
              if (!data.title || !Array.isArray(data.items)) {
                  alert("Error: Invalid Mindframe file.");
                  return;
              }

              chrome.storage.local.get({ boards: {} }, (r) => {
                  let newTitle = data.title;
                  if (r.boards[newTitle]) {
                      let c = 1;
                      while (r.boards[newTitle + " (" + c + ")"]) c++;
                      newTitle = newTitle + " (" + c + ")";
                  }
                  r.boards[newTitle] = data.items;
                  chrome.storage.local.set({ boards: r.boards }, () => {
                      if(confirm(`Imported "${newTitle}". Switch to it now?`)) {
                          // REBRAND Redirect
                          window.location.href = "mindframe.html?board=" + encodeURIComponent(newTitle);
                      }
                  });
              });
          } catch (err) {
              alert("Error reading file: " + err);
          }
      };
      reader.readAsText(file);
      e.target.value = ''; 
  });


  const imgInput = document.getElementById('img-upload');
  if(imgInput) {
      imgInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = (ev) => {
              const img = new Image();
              img.onload = () => {
                  let w = img.width;
                  let h = img.height;
                  if(w > 400) { h = (400/w)*h; w = 400; }
                  saveItem({
                     type: 'image', data: ev.target.result, 
                     left: '100px', top: '100px', width: w+'px', height: h+'px'
                  });
              }
              img.src = ev.target.result;
          };
          reader.readAsDataURL(file);
          e.target.value = ''; 
      });
  }

  // LOGIC
  let isDrawing = false;
  let currentPath = null;
  let points = [];

  board.addEventListener('mousedown', (e) => {
      if (e.target.closest('#toolbar') || e.target.closest('#board-title') || e.target.closest('.item')) return;
      if (currentTool === 'cursor' || currentTool === 'eraser') return;

      if (currentTool === 'text') {
          saveItem({
              type: 'text', data: '', 
              left: e.clientX + 'px', top: e.clientY + 'px', 
              width: '200px', height: '100px',
              isNew: true
          });
          document.getElementById('tool-cursor').click();
      }
      
      if (currentTool === 'pen') {
          isDrawing = true;
          points = [[e.clientX, e.clientY]];
          const ns = "http://www.w3.org/2000/svg";
          currentPath = document.createElementNS(ns, "path");
          currentPath.setAttribute("fill", "none");
          currentPath.setAttribute("stroke", document.body.classList.contains("dark-mode") ? "#eee" : "#333");
          currentPath.setAttribute("stroke-width", "3");
          currentPath.setAttribute("stroke-linecap", "round");
          currentPath.setAttribute("stroke-linejoin", "round");
          currentPath.setAttribute("d", `M ${e.clientX} ${e.clientY}`);
          const svg = document.createElementNS(ns, "svg");
          svg.style.position = "absolute"; svg.style.left = "0"; svg.style.top = "0";
          svg.style.width = "100%"; svg.style.height = "100%";
          svg.style.pointerEvents = "none";
          svg.style.zIndex = "9999"; 
          svg.id = "temp-drawing";
          svg.appendChild(currentPath);
          board.appendChild(svg);
      }
  });

  window.addEventListener('mousemove', (e) => {
      if (isDrawing && currentTool === 'pen') {
          points.push([e.clientX, e.clientY]);
          const d = points.map((p, i) => (i === 0 ? "M" : "L") + ` ${p[0]} ${p[1]}`).join(" ");
          currentPath.setAttribute("d", d);
      }
  });

  window.addEventListener('mouseup', (e) => {
      if (isDrawing && currentTool === 'pen') {
          isDrawing = false;
          const temp = document.getElementById('temp-drawing');
          if(temp) temp.remove();
          
          if (points.length > 2) {
             let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
             points.forEach(p => {
                 if(p[0] < minX) minX = p[0];
                 if(p[1] < minY) minY = p[1];
                 if(p[0] > maxX) maxX = p[0];
                 if(p[1] > maxY) maxY = p[1];
             });
             const pad = 5;
             minX -= pad; minY -= pad; maxX += pad; maxY += pad;
             const width = maxX - minX;
             const height = maxY - minY;
             const relPoints = points.map(p => [p[0] - minX, p[1] - minY]);
             const finalD = relPoints.map((p, i) => (i === 0 ? "M" : "L") + ` ${p[0]} ${p[1]}`).join(" ");

             saveItem({
                 type: 'drawing', data: finalD,
                 left: minX + 'px', top: minY + 'px', width: width + 'px', height: height + 'px'
             });
          }
      }
  });

  function renderItems(items, newItemIndex) {
      Array.from(board.children).forEach(c => {
          if(!['toolbar','board-title','temp-drawing'].includes(c.id)) c.remove();
      });

      items.forEach((item, index) => {
          let safeLeft = item.left || "50px";
          let safeTop = item.top || "50px";
          if(typeof safeLeft === 'number') safeLeft += 'px';
          if(typeof safeTop === 'number') safeTop += 'px';
          if(!safeLeft.endsWith('px') && !safeLeft.endsWith('%')) safeLeft += 'px';
          if(!safeTop.endsWith('px') && !safeTop.endsWith('%')) safeTop += 'px';

          if (item.type === 'drawing') {
              const ns = "http://www.w3.org/2000/svg";
              const svg = document.createElementNS(ns, "svg");
              svg.classList.add("item", "drawing-item");
              svg.style.left = safeLeft; svg.style.top = safeTop;
              svg.style.width = item.width || "100%"; svg.style.height = item.height || "100%";
              const path = document.createElementNS(ns, "path");
              path.setAttribute("d", item.data);
              svg.appendChild(path);
              path.addEventListener('mousedown', (e) => {
                  if (currentTool === 'eraser') { e.stopPropagation(); deleteItem(index); }
              });
              board.appendChild(svg);
              return;
          }

          const div = document.createElement("div");
          div.className = "item";
          div.style.left = safeLeft; div.style.top = safeTop;
          
          if (item.width) div.style.width = item.width;
          else div.style.width = "200px"; 
          if (item.height) div.style.height = item.height;
          else div.style.height = "150px";

          div.style.pointerEvents = currentTool === 'cursor' ? 'auto' : 'none';

          const delBtn = document.createElement("button");
          delBtn.className = "delete-btn"; delBtn.innerHTML = "×";
          delBtn.onclick = (ev) => { ev.stopPropagation(); deleteItem(index); };
          div.appendChild(delBtn);
          
          div.addEventListener('mousedown', (e) => {
              if (currentTool === 'eraser') { e.stopPropagation(); deleteItem(index); }
          });

          const handle = document.createElement("div");
          handle.className = "resize-handle";
          div.appendChild(handle);

          const isImage = item.type === 'image' || (item.data && (item.data.startsWith('http') || item.data.startsWith('data:image')));

          if (isImage) {
              div.classList.add('image-item');
              const img = document.createElement("img");
              img.src = item.data;
              div.appendChild(img);
              if (item.sourceUrl) {
                  const link = document.createElement("a");
                  link.className = "visit-link"; link.innerHTML = "🔗"; link.href = item.sourceUrl; link.target = "_blank";
                  div.appendChild(link);
              }
          } else {
              div.classList.add('text-item');
              const ta = document.createElement("textarea");
              ta.value = item.data || "";
              ta.placeholder = "Double-click to edit...";
              ta.oninput = () => saveText(index, ta.value);
              ta.style.pointerEvents = "none";
              
              div.addEventListener('dblclick', (e) => {
                  if (currentTool !== 'cursor') return;
                  ta.style.pointerEvents = "auto";
                  ta.focus();
                  div.style.cursor = "text";
                  div.draggable = false; 
              });

              ta.addEventListener('blur', () => {
                  ta.style.pointerEvents = "none";
                  div.style.cursor = "default";
                  saveText(index, ta.value);
              });
              
              if (index === newItemIndex) {
                  setTimeout(() => {
                      ta.style.pointerEvents = "auto";
                      ta.focus();
                  }, 50);
              }

              div.appendChild(ta);
          }

          setupDragging(div, index);
          setupCustomResizing(handle, div, index, isImage);

          board.appendChild(div);
      });
      
      if (currentTool === 'eraser') document.body.classList.add('eraser-mode');
      else document.body.classList.remove('eraser-mode');
  }

  function saveItem(item) {
      chrome.storage.local.get({ boards: {} }, r => {
          if(!r.boards[boardParam]) r.boards[boardParam] = [];
          r.boards[boardParam].push(item);
          const newIndex = item.isNew ? r.boards[boardParam].length - 1 : -1;
          if(item.isNew) delete item.isNew; 
          chrome.storage.local.set({ boards: r.boards }, () => {
              renderItems(r.boards[boardParam] || [], newIndex);
          });
      });
  }

  function deleteItem(index) {
      chrome.storage.local.get({ boards: {} }, r => {
          r.boards[boardParam].splice(index, 1);
          chrome.storage.local.set({ boards: r.boards }, () => loadAndRender(boardParam));
      });
  }

  function saveText(index, txt) {
      chrome.storage.local.get({ boards: {} }, r => {
          if(r.boards[boardParam] && r.boards[boardParam][index]) {
             r.boards[boardParam][index].data = txt;
             chrome.storage.local.set({ boards: r.boards });
          }
      });
  }

  function checkAutoExpand(currentY, elementHeight) {
      const docH = Math.max(document.body.scrollHeight, document.body.offsetHeight);
      const bottomZone = docH * 0.75;
      if ((currentY + elementHeight) > bottomZone) {
          document.getElementById('board').style.minHeight = (docH * 1.25) + "px";
      }
  }

  function setupDragging(div, index) {
      let isDrag = false, offX, offY;
      div.addEventListener("mousedown", e => {
          if(currentTool !== 'cursor') return;
          if (e.target.classList.contains('resize-handle')) return;
          if (e.target.tagName === 'TEXTAREA' && e.target.style.pointerEvents === 'auto') return;
          if (['BUTTON','A'].includes(e.target.tagName)) return;
          
          e.preventDefault(); 
          isDrag = true; 
          offX = e.clientX - div.offsetLeft; 
          offY = e.clientY - div.offsetTop;
          div.style.zIndex = 999;
      });
      window.addEventListener("mousemove", e => {
          if(!isDrag) return;
          const newX = e.clientX - offX;
          const newY = e.clientY - offY;
          div.style.left = newX + "px"; 
          div.style.top = newY + "px";
          checkAutoExpand(newY, div.offsetHeight);
      });
      window.addEventListener("mouseup", () => {
          if(isDrag) { 
             isDrag = false; div.style.zIndex = "auto"; 
             saveProp(index, {left: div.style.left, top: div.style.top}); 
          }
      });
  }

  function setupCustomResizing(handle, div, index, isImage) {
      let isResizing = false;
      let startX, startY, startW, startH, ratio;
      handle.addEventListener("mousedown", (e) => {
          if (currentTool !== 'cursor') return;
          e.stopPropagation(); e.preventDefault();
          isResizing = true;
          startX = e.clientX; startY = e.clientY;
          startW = parseInt(window.getComputedStyle(div).width, 10);
          startH = parseInt(window.getComputedStyle(div).height, 10);
          ratio = startW / startH;
          div.style.zIndex = 1000;
      });
      window.addEventListener("mousemove", (e) => {
          if (!isResizing) return;
          const dx = e.clientX - startX;
          const dy = e.clientY - startY;
          let newW = Math.max(50, startW + dx);
          let newH = isImage ? (newW / ratio) : Math.max(30, startH + dy);
          div.style.width = newW + 'px'; div.style.height = newH + 'px';
          checkAutoExpand(div.offsetTop, newH);
      });
      window.addEventListener("mouseup", () => {
          if (isResizing) {
              isResizing = false; div.style.zIndex = "auto";
              saveProp(index, {width: div.style.width, height: div.style.height});
          }
      });
  }

  function saveProp(index, props) {
      chrome.storage.local.get({ boards: {} }, r => {
          if(r.boards[boardParam] && r.boards[boardParam][index]) {
             Object.assign(r.boards[boardParam][index], props);
             chrome.storage.local.set({ boards: r.boards });
          }
      });
  }

  function loadAndRender(name) {
      chrome.storage.local.get({ boards: {} }, r => renderItems(r.boards[name] || []));
  }
  
  boardTitle.addEventListener("input", () => { document.title = boardTitle.innerText; });
  boardTitle.addEventListener("blur", () => {
      const newName = boardTitle.innerText.trim();
      if(newName === boardParam || !newName) return;
      chrome.storage.local.get({ boards: {} }, r => {
          if(r.boards[newName]) { alert("Exists!"); boardTitle.innerText = boardParam; return; }
          r.boards[newName] = r.boards[boardParam]; delete r.boards[boardParam];
          chrome.storage.local.set({ boards: r.boards }, () => {
             const u = new URL(location); u.searchParams.set("board", newName);
             history.pushState({}, "", u); boardParam = newName; document.title = newName;
          });
      });
  });

  loadAndRender(boardParam);
  chrome.runtime.onMessage.addListener(m => {
      if(m.type === "refresh-board" && m.board === boardParam) loadAndRender(boardParam);
  });
});
