document.addEventListener("DOMContentLoaded", () => {
  const board = document.getElementById("board");
  const urlParams = new URLSearchParams(window.location.search);
  let boardParam = urlParams.get("board") || "Untitled";
  let currentTool = 'cursor';

  // --- Title & Size Logic ---
  let titleWrapper = document.getElementById("title-wrapper");
  let boardTitle = document.getElementById("board-title");
  
  if (!titleWrapper) {
      titleWrapper = document.createElement("div");
      titleWrapper.id = "title-wrapper";
      const btnDown = document.createElement("button");
      btnDown.className = "title-btn"; btnDown.innerText = "-";
      boardTitle = document.createElement("h1");
      boardTitle.id = "board-title";
      boardTitle.contentEditable = true; boardTitle.spellcheck = false;
      const btnUp = document.createElement("button");
      btnUp.className = "title-btn"; btnUp.innerText = "+";
      
      titleWrapper.appendChild(btnDown);
      titleWrapper.appendChild(boardTitle);
      titleWrapper.appendChild(btnUp);
      document.body.appendChild(titleWrapper);

      const changeSize = (delta) => {
          let s = parseInt(window.getComputedStyle(boardTitle).fontSize);
          s = Math.max(12, Math.min(72, s + delta));
          boardTitle.style.fontSize = s + "px";
          saveSettings();
      };
      btnDown.onclick = () => changeSize(-2);
      btnUp.onclick = () => changeSize(2);
      titleWrapper.addEventListener("wheel", (e) => {
          e.preventDefault(); changeSize(e.deltaY < 0 ? 2 : -2);
      }, { passive: false });
  }

  boardTitle.textContent = boardParam;
  document.title = boardParam;

  function loadSettings() {
      chrome.storage.local.get({ board_settings: {} }, (r) => {
          const settings = r.board_settings[boardParam];
          if (settings && settings.titleSize) { boardTitle.style.fontSize = settings.titleSize; }
      });
  }
  function saveSettings() {
      chrome.storage.local.get({ board_settings: {} }, (r) => {
          if (!r.board_settings[boardParam]) r.board_settings[boardParam] = {};
          r.board_settings[boardParam].titleSize = boardTitle.style.fontSize;
          chrome.storage.local.set({ board_settings: r.board_settings });
      });
  }
  loadSettings();

  boardTitle.addEventListener("blur", () => {
      const newName = boardTitle.innerText.trim();
      if(newName === boardParam || !newName) { boardTitle.innerText = boardParam; return; }
      chrome.storage.local.get({ boards: {}, board_settings: {} }, r => {
          if(r.boards[newName]) { alert("Board exists!"); boardTitle.innerText = boardParam; return; }
          r.boards[newName] = r.boards[boardParam]; delete r.boards[boardParam];
          if (r.board_settings[boardParam]) {
              r.board_settings[newName] = r.board_settings[boardParam]; delete r.board_settings[boardParam];
          }
          chrome.storage.local.set({ boards: r.boards, board_settings: r.board_settings }, () => {
             const u = new URL(location); u.searchParams.set("board", newName);
             history.pushState({}, "", u); boardParam = newName; document.title = newName;
          });
      });
  });

  // --- Theme Logic ---
  const themeBtn = document.getElementById('tool-theme');
  function updateTheme(isDark) { document.body.classList.toggle('dark-mode', isDark); }
  
  chrome.storage.local.get({ theme: 'system' }, r => {
      if (r.theme === 'system') updateTheme(window.matchMedia('(prefers-color-scheme: dark)').matches);
      else updateTheme(r.theme === 'dark');
  });

  if (themeBtn) {
      themeBtn.addEventListener('click', () => {
          const isDark = !document.body.classList.contains('dark-mode');
          updateTheme(isDark);
          chrome.storage.local.set({ theme: isDark ? 'dark' : 'light' });
      });
  }

  // --- Toolbar Setup ---
  const tools = {
      'tool-cursor': 'cursor', 'tool-text': 'text', 'tool-image': 'image',
      'tool-pen': 'pen', 'tool-arrow': 'arrow', 'tool-eraser': 'eraser'
  };

  Object.keys(tools).forEach(id => {
      const el = document.getElementById(id);
      if(el) {
          el.addEventListener('click', (e) => {
              if (tools[id] === 'image') { document.getElementById('img-upload').click(); return; }
              currentTool = tools[id];
              document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
              document.getElementById(id).classList.add('active');
              
              document.body.classList.remove('eraser-mode');
              board.style.cursor = 'default';
              
              if (currentTool === 'eraser') {
                  document.body.classList.add('eraser-mode');
                  board.style.cursor = 'cell';
              } else if (currentTool === 'text') {
                  board.style.cursor = 'text';
              } else if (currentTool === 'pen' || currentTool === 'arrow') {
                  board.style.cursor = 'crosshair';
              }
              
              document.querySelectorAll('.item').forEach(el => {
                   if (currentTool !== 'eraser') {
                      el.style.pointerEvents = (currentTool === 'cursor') ? 'auto' : 'none';
                   }
              });
          });
      }
  });

  // --- EXPORT AS WEBPAGE (HTML) ---
  document.getElementById('tool-publish').addEventListener('click', () => {
      chrome.storage.local.get({ boards: {} }, r => {
          const items = r.boards[boardParam] || [];
          const title = boardParam;
          const titleSize = boardTitle.style.fontSize || '24px';
          
          const isDark = document.body.classList.contains('dark-mode');
          const cssVars = isDark 
            ? ':root { --bg-color: #1a1a1a; --dot-color: #333; --item-bg: #2a2a2a; --shadow: 0 4px 12px rgba(0,0,0,0.3); --text-color: #ffffff; }' 
            : ':root { --bg-color: #f7f7f7; --dot-color: #d1d1d1; --item-bg: #fff; --shadow: 0 4px 12px rgba(0,0,0,0.08); --text-color: #000000; }';

          let html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    ${cssVars}
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background-color: var(--bg-color); background-image: radial-gradient(var(--dot-color) 1px, transparent 1px); background-size: 20px 20px; background-attachment: fixed; color: var(--text-color); overflow: auto; }
    h1 { position: fixed; top: 20px; left: 50%; transform: translateX(-50%); margin: 0; font-size: ${titleSize}; z-index: 1000; pointer-events: none; opacity: 1; color: var(--text-color); }
    .item { position: absolute; border-radius: 8px; user-select: none; }
    .image-item { background: var(--item-bg); box-shadow: var(--shadow); border: 1px solid rgba(0,0,0,0.05); overflow: hidden; display: flex; transition: transform 0.15s ease; }
    .image-item img { width: 100%; height: 100%; object-fit: contain; display: block; }
    a.image-item { cursor: pointer; }
    a.image-item:hover { transform: scale(1.02); box-shadow: 0 8px 20px rgba(0,0,0,0.15); z-index: 100; }
    .text-item { padding: 8px; background: transparent; white-space: pre-wrap; font-family: "Georgia", serif; font-size: 18px; line-height: 1.5; color: inherit; }
    
    .drawing-item { color: inherit; }
    .drawing-item svg { overflow: visible; }
    .drawing-item path { fill: none; stroke: currentColor; stroke-width: 3px; stroke-linecap: round; stroke-linejoin: round; vector-effect: non-scaling-stroke; }
    .arrow-head { fill: currentColor; stroke: none; }
  </style>
</head>
<body>
  <h1>${title}</h1>
  <div id="board">
`;

          items.forEach((item, index) => {
              let style = `left:${item.left}; top:${item.top}; width:${item.width||'200px'}; height:${item.height||'150px'};`;
              if (item.type === 'image' || (item.data && item.data.startsWith('data:image'))) {
                  if (item.sourceUrl) {
                      html += `<a href="${item.sourceUrl}" target="_blank" class="item image-item" style="${style}"><img src="${item.data}"></a>`;
                  } else {
                      html += `<div class="item image-item" style="${style}"><img src="${item.data}"></div>`;
                  }
              } 
              else if (item.type === 'text') {
                  html += `<div class="item text-item" style="${style}">${item.data}</div>`;
              }
              else if (item.type === 'drawing' || item.type === 'arrow') {
                  let svgContent = `<path d="${item.data}" />`;
                  if (item.type === 'arrow') {
                       svgContent += `<defs><marker id="arrow-${index}" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto"><polygon points="0 0, 10 3.5, 0 7" class="arrow-head"/></marker></defs>`;
                       svgContent = svgContent.replace('<path', `<path marker-end="url(#arrow-${index})"`);
                  }
                  html += `<div class="item drawing-item" style="${style}"><svg width="100%" height="100%">${svgContent}</svg></div>`;
              }
          });
          html += `</div></body></html>`;
          const blob = new Blob([html], { type: "text/html" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a'); a.href = url; a.download = `${title}.html`; a.click();
      });
  });
  
  // --- Export JSON ---
  document.getElementById('tool-export').addEventListener('click', () => {
      chrome.storage.local.get({ boards: {} }, r => {
          const data = r.boards[boardParam] || [];
          const json = JSON.stringify({ title: boardParam, items: data });
          const blob = new Blob([json], { type: "application/json" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a'); a.href = url; a.download = `Mindframe - ${boardParam}.json`; a.click();
      });
  });

  const importInput = document.getElementById('file-import');
  document.getElementById('tool-import').addEventListener('click', () => importInput.click());
  importInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
          try {
              const data = JSON.parse(ev.target.result);
              if (!data.title || !Array.isArray(data.items)) throw new Error("Invalid Format");
              chrome.storage.local.get({ boards: {} }, (r) => {
                  let newTitle = data.title;
                  if (r.boards[newTitle]) newTitle += " (Imported)";
                  r.boards[newTitle] = data.items;
                  chrome.storage.local.set({ boards: r.boards }, () => {
                      window.location.href = "mindframe.html?board=" + encodeURIComponent(newTitle);
                  });
              });
          } catch (err) { alert("Error: " + err); }
      };
      reader.readAsText(file);
      e.target.value = ''; 
  });

  const imgInput = document.getElementById('img-upload');
  if(imgInput) {
      imgInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = (ev) => {
              const img = new Image();
              img.onload = () => {
                  let w = img.width > 400 ? 400 : img.width;
                  let h = img.width > 400 ? (400/img.width)*img.height : img.height;
                  saveItem({
                     type: 'image', data: ev.target.result, 
                     left: '100px', top: '100px', width: w+'px', height: h+'px'
                  });
              }
              img.src = ev.target.result;
          };
          reader.readAsDataURL(file);
          e.target.value = ''; 
      });
  }

  // --- Logic ---
  let isDrawing = false;
  let startP = null;
  let currentSvg = null;
  let points = [];

  let dragState = { active: false, element: null, index: -1, startX: 0, startY: 0, startLeft: 0, startTop: 0 };

  board.addEventListener('mousedown', (e) => {
      // 1. Check for Drag
      if (currentTool === 'cursor') {
          const item = e.target.closest('.item');
          if (item) {
              const index = parseInt(item.getAttribute('data-index'));
              
              if (e.target.classList.contains('resize-handle')) return;
              if (e.target.tagName === 'TEXTAREA' && e.target.style.pointerEvents === 'auto') return;
              if (['BUTTON', 'A'].includes(e.target.tagName)) return;

              document.querySelectorAll('.item').forEach(i => i.style.zIndex = "1");
              item.style.zIndex = "10";

              e.preventDefault(); 
              dragState = {
                  active: true, element: item, index: index,
                  startX: e.clientX, startY: e.clientY,
                  startLeft: parseFloat(item.style.left) || 0, startTop: parseFloat(item.style.top) || 0
              };
              return;
          }
      }

      // 2. Eraser
      if (currentTool === 'eraser') {
          const item = e.target.closest('.item');
          if (item) {
             e.stopPropagation(); deleteItem(parseInt(item.getAttribute('data-index'))); return;
          }
      }

      // 3. Drawing
      if (e.target.closest('#toolbar') || e.target.closest('#title-wrapper')) return;
      
      // FIX: Allow drawing over items by not checking e.target.closest('.item')
      if (['cursor', 'eraser'].includes(currentTool)) return;

      if (currentTool === 'text') {
          saveItem({
              type: 'text', data: '', 
              left: e.clientX + 'px', top: e.clientY + 'px', 
              width: '200px', height: '100px', isNew: true
          });
          document.getElementById('tool-cursor').click();
          return;
      }
      
      isDrawing = true;
      startP = [e.clientX, e.clientY];
      points = [startP];

      const ns = "http://www.w3.org/2000/svg";
      currentSvg = document.createElementNS(ns, "svg");
      Object.assign(currentSvg.style, {
          position: "absolute", left: "0", top: "0", width: "100%", height: "100%",
          pointerEvents: "none", zIndex: "9999"
      });
      
      const path = document.createElementNS(ns, "path");
      path.setAttribute("fill", "none");
      path.setAttribute("stroke", document.body.classList.contains("dark-mode") ? "#ffffff" : "#333");
      path.setAttribute("stroke-width", "3");
      path.setAttribute("stroke-linecap", "round");
      path.setAttribute("d", `M ${startP[0]} ${startP[1]}`);
      
      currentSvg.appendChild(path);
      board.appendChild(currentSvg);
  });

  window.addEventListener('mousemove', (e) => {
      if (dragState.active) {
          if (e.buttons === 0) { endDrag(); return; }
          const deltaX = e.clientX - dragState.startX;
          const deltaY = e.clientY - dragState.startY;
          dragState.element.style.left = (dragState.startLeft + deltaX) + "px";
          dragState.element.style.top = (dragState.startTop + deltaY) + "px";
          return;
      }

      if (!isDrawing) return;
      
      if (currentTool === 'pen') {
          points.push([e.clientX, e.clientY]);
          const d = points.map((p, i) => (i === 0 ? "M" : "L") + ` ${p[0]} ${p[1]}`).join(" ");
          currentSvg.querySelector('path').setAttribute("d", d);
      } else if (currentTool === 'arrow') {
          const d = `M ${startP[0]} ${startP[1]} L ${e.clientX} ${e.clientY}`;
          currentSvg.querySelector('path').setAttribute("d", d);
      }
  });

  window.addEventListener('mouseup', (e) => {
      if (dragState.active) { endDrag(); return; }

      if (!isDrawing) return;
      isDrawing = false;
      const finalP = [e.clientX, e.clientY];
      
      // FIX: Don't remove currentSvg immediately to prevent flicker
      // currentSvg will be removed when renderItems calls board.children cleanup

      let xs = currentTool==='arrow' ? [startP[0], finalP[0]] : points.map(p=>p[0]);
      let ys = currentTool==='arrow' ? [startP[1], finalP[1]] : points.map(p=>p[1]);
      
      let minX = Math.min(...xs) - 10;
      let minY = Math.min(...ys) - 10;
      let maxX = Math.max(...xs) + 10;
      let maxY = Math.max(...ys) + 10;
      let w = maxX - minX;
      let h = maxY - minY;
      
      let dataD = "";
      if (currentTool === 'arrow') {
          dataD = `M ${startP[0]-minX} ${startP[1]-minY} L ${finalP[0]-minX} ${finalP[1]-minY}`;
      } else {
          dataD = points.map((p, i) => (i === 0 ? "M" : "L") + ` ${p[0]-minX} ${p[1]-minY}`).join(" ");
      }

      if (w > 5 && h > 5) {
          saveItem({
              type: currentTool === 'arrow' ? 'arrow' : 'drawing', 
              data: dataD,
              left: minX + 'px', top: minY + 'px', width: w + 'px', height: h + 'px'
          });
      } else {
          // If too small, remove the temp svg immediately
          if(currentSvg) currentSvg.remove();
      }
  });

  function endDrag() {
      if (!dragState.active) return;
      saveProp(dragState.index, { left: dragState.element.style.left, top: dragState.element.style.top });
      dragState.active = false; dragState.element = null;
  }

  function renderItems(items, newItemIndex) {
      Array.from(board.children).forEach(c => {
          if(!['toolbar','title-wrapper'].includes(c.id)) c.remove();
      });

      items.forEach((item, index) => {
          const div = document.createElement("div");
          div.className = "item";
          div.setAttribute("data-index", index); 
          div.style.left = item.left; div.style.top = item.top;
          div.style.width = item.width || "200px"; div.style.height = item.height || "150px";

          // Conditional Resize Handle
          if (item.type !== 'drawing' && item.type !== 'arrow') {
             const handle = document.createElement("div");
             handle.className = "resize-handle";
             div.appendChild(handle);
             setupCustomResizing(handle, div, index, item.type === 'image' || div.classList.contains('image-item'));
          }

          if (item.type === 'drawing' || item.type === 'arrow') {
              div.classList.add("drawing-item");
              const ns = "http://www.w3.org/2000/svg";
              const svg = document.createElementNS(ns, "svg");
              svg.style.width = "100%"; svg.style.height = "100%"; svg.style.overflow = "visible";
              
              if (item.type === 'arrow') {
                  const defs = document.createElementNS(ns, "defs");
                  const marker = document.createElementNS(ns, "marker");
                  marker.id = "arrowhead-" + index;
                  marker.setAttribute("markerWidth", "10"); marker.setAttribute("markerHeight", "7");
                  marker.setAttribute("refX", "9"); marker.setAttribute("refY", "3.5");
                  marker.setAttribute("orient", "auto");
                  const poly = document.createElementNS(ns, "polygon");
                  poly.setAttribute("points", "0 0, 10 3.5, 0 7");
                  poly.classList.add("arrow-head");
                  marker.appendChild(poly); defs.appendChild(marker); svg.appendChild(defs);
              }

              const path = document.createElementNS(ns, "path");
              path.setAttribute("d", item.data);
              if (item.type === 'arrow') path.setAttribute("marker-end", `url(#arrowhead-${index})`);
              svg.appendChild(path); div.appendChild(svg);
          } 
          else if (item.type === 'image' || (item.data && item.data.startsWith('data:image'))) {
              div.classList.add('image-item');
              const img = document.createElement("img");
              img.src = item.data;
              div.appendChild(img);
              if (item.sourceUrl) {
                  const link = document.createElement("a");
                  link.className = "visit-link"; link.innerHTML = "🔗"; link.href = item.sourceUrl; link.target = "_blank";
                  div.appendChild(link);
              }
          } else {
              div.classList.add('text-item');
              const ta = document.createElement("textarea");
              ta.value = item.data || "";
              ta.placeholder = "Type here...";
              ta.oninput = () => saveText(index, ta.value);
              ta.style.pointerEvents = "none";
              
              div.addEventListener('dblclick', () => {
                  if (currentTool !== 'cursor') return;
                  ta.style.pointerEvents = "auto"; ta.focus(); div.draggable = false;
              });
              ta.addEventListener('blur', () => {
                  ta.style.pointerEvents = "none"; div.draggable = true; saveText(index, ta.value);
              });
              if (index === newItemIndex) setTimeout(() => { ta.style.pointerEvents="auto"; ta.focus(); }, 50);
              div.appendChild(ta);
          }

          board.appendChild(div);
      });
  }

  function saveItem(item) {
      chrome.storage.local.get({ boards: {} }, r => {
          if(!r.boards[boardParam]) r.boards[boardParam] = [];
          r.boards[boardParam].push(item);
          const newIndex = item.isNew ? r.boards[boardParam].length - 1 : -1;
          if(item.isNew) delete item.isNew; 
          chrome.storage.local.set({ boards: r.boards }, () => renderItems(r.boards[boardParam] || [], newIndex));
      });
  }

  function deleteItem(index) {
      chrome.storage.local.get({ boards: {} }, r => {
          r.boards[boardParam].splice(index, 1);
          chrome.storage.local.set({ boards: r.boards }, () => loadAndRender(boardParam));
      });
  }

  function saveText(index, txt) {
      chrome.storage.local.get({ boards: {} }, r => {
          if(r.boards[boardParam] && r.boards[boardParam][index]) {
             r.boards[boardParam][index].data = txt;
             chrome.storage.local.set({ boards: r.boards });
          }
      });
  }

  function setupCustomResizing(handle, div, index, lockRatio) {
      let isResizing = false, startX, startY, startW, startH, ratio;
      handle.addEventListener("mousedown", (e) => {
          if (currentTool !== 'cursor') return;
          e.stopPropagation(); e.preventDefault();
          isResizing = true; startX = e.clientX; startY = e.clientY;
          startW = div.offsetWidth; startH = div.offsetHeight;
          ratio = startW / startH;
      });
      window.addEventListener("mousemove", (e) => {
          if (!isResizing) return;
          let newW = Math.max(50, startW + (e.clientX - startX));
          let newH = lockRatio ? (newW / ratio) : Math.max(30, startH + (e.clientY - startY));
          div.style.width = newW + 'px'; div.style.height = newH + 'px';
      });
      window.addEventListener("mouseup", () => {
          if (isResizing) { isResizing = false; saveProp(index, {width: div.style.width, height: div.style.height}); }
      });
  }

  function saveProp(index, props) {
      chrome.storage.local.get({ boards: {} }, r => {
          if(r.boards[boardParam] && r.boards[boardParam][index]) {
             Object.assign(r.boards[boardParam][index], props);
             chrome.storage.local.set({ boards: r.boards });
          }
      });
  }

  function loadAndRender(name) {
      chrome.storage.local.get({ boards: {} }, r => renderItems(r.boards[name] || []));
  }
  
  loadAndRender(boardParam);
  chrome.runtime.onMessage.addListener(m => {
      if(m.type === "refresh-board" && m.board === boardParam) loadAndRender(boardParam);
  });
});