
window.onload = () => {
    const fileInput = document.getElementById('fileInput');
    const msg = document.getElementById('message');

    // 1. Try to open immediately
    setTimeout(() => {
        fileInput.click();
    }, 100);

    // 2. Fallback: Click anywhere on page triggers it
    document.body.addEventListener('click', () => {
        fileInput.click();
    });

    // 3. Handle File Selection
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        msg.textContent = "Importing...";
        
        const reader = new FileReader();
        reader.onload = (ev) => {
            try {
                const data = JSON.parse(ev.target.result);
                if (!data.title || !Array.isArray(data.items)) {
                    alert("Error: Invalid JSON format.");
                    return;
                }

                chrome.storage.local.get({ boards: {} }, (r) => {
                    let newTitle = data.title;
                    if (r.boards[newTitle]) {
                        let c = 1;
                        while (r.boards[newTitle + " (" + c + ")"]) c++;
                        newTitle = newTitle + " (" + c + ")";
                    }
                    r.boards[newTitle] = data.items;
                    chrome.storage.local.set({ boards: r.boards }, () => {
                        // Redirect current tab to the new board
                        window.location.href = "easel.html?board=" + encodeURIComponent(newTitle);
                    });
                });
            } catch (err) {
                alert("Error: " + err.message);
            }
        };
        reader.readAsText(file);
    });
};
