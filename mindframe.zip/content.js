(function(){if(window.hC)return;window.hC=true;
const ov=document.createElement("div");Object.assign(ov.style,{position:"fixed",pointerEvents:"none",background:"rgba(66,133,244,0.1)",border:"2px solid #4285f4",zIndex:2147483647,top:0,left:0,width:0,height:0,transition:"0.1s",boxShadow:"0 0 0 9999px rgba(0,0,0,0.3)"});
document.body.appendChild(ov);
function h(e){const r=e.target.getBoundingClientRect();Object.assign(ov.style,{top:r.top+"px",left:r.left+"px",width:r.width+"px",height:r.height+"px"});}
function c(e){e.preventDefault();e.stopPropagation();document.removeEventListener("mouseover",h);document.removeEventListener("click",c);ov.remove();window.hC=false;
const n=document.createElement("div");n.textContent="📸 Snapping...";Object.assign(n.style,{position:"fixed",top:"20px",left:"50%",transform:"translateX(-50%)",padding:"10px",background:"#333",color:"#fff",borderRadius:"20px",zIndex:2147483647});document.body.appendChild(n);
const tP=new Promise((_,r)=>setTimeout(()=>r(new Error("Timeout")),3000));
Promise.race([html2canvas(e.target,{useCORS:true,allowTaint:false,logging:false,backgroundColor:null,imageTimeout:2000}),tP])
.then(cv=>{s(cv.toDataURL());n.textContent="✅";}).catch(()=>{
const cv=document.createElement("canvas");cv.width=300;cv.height=100;const x=cv.getContext("2d");x.fillStyle="#eee";x.fillRect(0,0,300,100);x.fillStyle="#555";x.font="20px sans";x.fillText("Protected",20,55);
s(cv.toDataURL());n.textContent="⚠️ Saved Text/Placeholder";}).finally(()=>setTimeout(()=>n.remove(),2000));}
function s(d){chrome.storage.local.get({boards:{}},r=>{const bs=r.boards;const b="Quick Captures";if(!bs[b])bs[b]=[];
bs[b].push({data:d,sourceUrl:location.href,time:Date.now(),left:"50px",top:"200px",type:"image"});chrome.storage.local.set({boards:bs});});}
document.addEventListener("mouseover",h);document.addEventListener("click",c,{once:true});})();