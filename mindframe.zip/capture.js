(() => {
  // --- CLEANUP PREVIOUS OVERLAYS ---
  const oldOverlay = document.getElementById('mindframe-overlay');
  const oldBox = document.getElementById('mindframe-selbox');
  const oldContainer = document.getElementById('mindframe-overlay-container'); // From the failed shadow dom attempt
  if (oldOverlay) oldOverlay.remove();
  if (oldBox) oldBox.remove();
  if (oldContainer) oldContainer.remove();

  // --- 1. CREATE ELEMENTS ---
  
  // The Overlay (Visual Tint & Click Catcher)
  const overlay = document.createElement('div');
  overlay.id = 'mindframe-overlay';
  Object.assign(overlay.style, {
    position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh',
    zIndex: '2147483646', // High Z-Index
    background: 'rgba(0,0,0,0.1)',
    cursor: 'crosshair',
    display: 'block'
  });

  // The Selection Box (Red Rectangle)
  const selBox = document.createElement('div');
  selBox.id = 'mindframe-selbox';
  Object.assign(selBox.style, {
    position: 'fixed', 
    border: '2px solid #ff4f00', 
    background: 'rgba(255, 79, 0, 0.1)',
    zIndex: '2147483647', // Higher than overlay
    display: 'none', 
    pointerEvents: 'none', // Allow clicks to pass through to overlay if needed
    left: '0', top: '0', width: '0', height: '0'
  });

  // Append to <html> to be safe
  document.documentElement.appendChild(overlay);
  document.documentElement.appendChild(selBox);

  // --- 2. LOGIC ---
  let startX = 0, startY = 0;
  let isDragging = false;

  // KEY FIX: usage of { capture: true }
  // This tells the browser: "Run this function BEFORE letting the website see the click."
  
  function onMouseDown(e) {
    if (e.button !== 0) return; // Left click only
    e.preventDefault(); 
    e.stopPropagation(); // Stop website from reacting

    startX = e.clientX; 
    startY = e.clientY;
    isDragging = true;

    selBox.style.display = 'block';
    selBox.style.transform = `translate3d(${startX}px, ${startY}px, 0)`;
    selBox.style.width = '0px'; 
    selBox.style.height = '0px';
  }

  function onMouseMove(e) {
    if (!isDragging) return;
    e.preventDefault(); 
    e.stopPropagation();

    const currentX = e.clientX;
    const currentY = e.clientY;

    const width = Math.abs(currentX - startX);
    const height = Math.abs(currentY - startY);
    const left = Math.min(currentX, startX);
    const top = Math.min(currentY, startY);

    // Use transform for performance, but simple left/top/width/height works reliably too
    selBox.style.transform = `translate3d(${left}px, ${top}px, 0)`;
    selBox.style.width = width + 'px';
    selBox.style.height = height + 'px';
  }

  function onMouseUp(e) {
    if (!isDragging) return;
    e.preventDefault(); 
    e.stopPropagation();
    isDragging = false;

    // Get final rect
    const rect = selBox.getBoundingClientRect();

    // Cleanup Listeners & DOM
    cleanup();

    if (rect.width < 5 || rect.height < 5) return;

    // --- CAPTURE SCREENSHOT ---
    const pageTitle = document.title;
    const faviconLink = document.querySelector("link[rel*='icon']");
    const favicon = faviconLink ? faviconLink.href : (location.origin + "/favicon.ico");

    chrome.runtime.sendMessage({ type: 'mindframe-get-screen' }, response => {
        if (!response || !response.dataUrl) return;
        
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const dpr = window.devicePixelRatio || 1;
            canvas.width = rect.width * dpr; 
            canvas.height = rect.height * dpr;
            const ctx = canvas.getContext('2d');
            
            // Crop the screenshot
            ctx.drawImage(img, 
                rect.left * dpr, rect.top * dpr, 
                rect.width * dpr, rect.height * dpr, 
                0, 0, canvas.width, canvas.height
            );
            
            chrome.runtime.sendMessage({
                type: 'mindframe-shot-ready',
                image: canvas.toDataURL('image/png'),
                pageUrl: location.href,
                pageTitle: pageTitle,
                favicon: favicon,
                width: rect.width, height: rect.height
            });
        };
        img.src = response.dataUrl;
    });
  }

  function cleanup() {
      window.removeEventListener('mousedown', onMouseDown, true);
      window.removeEventListener('mousemove', onMouseMove, true);
      window.removeEventListener('mouseup', onMouseUp, true);
      if (overlay) overlay.remove();
      if (selBox) selBox.remove();
  }

  // Attach Capture Phase Listeners
  window.addEventListener('mousedown', onMouseDown, true);
  window.addEventListener('mousemove', onMouseMove, true);
  window.addEventListener('mouseup', onMouseUp, true);

  // Escape to Cancel
  window.addEventListener('keydown', function escHandler(e) {
    if (e.key === 'Escape') {
      cleanup();
      window.removeEventListener('keydown', escHandler);
    }
  });

  // --- POPUP MENU (Save to...) ---
  chrome.runtime.onMessage.addListener(msg => {
    if (msg.type === 'mindframe-show-menu') {
       if(document.getElementById('mindframe-menu')) return;

       const { boards } = msg;
       const menu = document.createElement('div');
       menu.id = 'mindframe-menu';
       Object.assign(menu.style, {
         position: 'fixed', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
         background: '#fff', padding: '15px', border: '1px solid #eee', zIndex: '2147483647',
         borderRadius: '12px', boxShadow: '0 10px 40px rgba(0,0,0,0.2)', 
         fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
         color: '#333', fontSize: '14px', textAlign: 'center', minWidth: '200px'
       });
       
       const title = document.createElement('div');
       title.textContent = "Save to Easel";
       title.style.fontWeight = "600"; title.style.marginBottom="12px";
       menu.appendChild(title);

       const createBtn = (text, cb) => {
           const b = document.createElement('button');
           b.textContent = text; 
           Object.assign(b.style, {
               display: 'block', width: '100%', margin: '6px 0', padding: '8px 12px',
               cursor: 'pointer', border: 'none', background: '#f2f2f2', borderRadius: '6px',
               textAlign: 'left', fontSize: '13px', color: '#333'
           });
           b.onmouseenter = () => b.style.background = "#e5e5e5";
           b.onmouseleave = () => b.style.background = "#f2f2f2";
           b.onclick = () => { cb(); menu.remove(); };
           menu.appendChild(b);
       };
       
       createBtn('➕ New Mindframe', () => chrome.runtime.sendMessage({type: 'mindframe-create-new-live-shot'}));
       boards.forEach(b => createBtn(b, () => chrome.runtime.sendMessage({type: 'mindframe-add-live-shot', board: b})));
       
       const close = document.createElement('div');
       close.textContent = "Cancel";
       close.style.marginTop="10px"; close.style.fontSize="12px"; close.style.color="#999"; close.style.cursor="pointer";
       close.onclick = () => menu.remove();
       menu.appendChild(close);

       document.documentElement.appendChild(menu);
    }
  });
})();