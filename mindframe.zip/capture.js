
(() => {
  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
    cursor: 'crosshair', background: 'rgba(0,0,0,0.05)', zIndex: 999999999
  });
  document.body.appendChild(overlay);

  let startX, startY, selBox;
  let isDragging = false;

  function onMouseDown(e) {
    if (e.button !== 0) return;
    e.preventDefault(); e.stopPropagation();

    startX = e.clientX; startY = e.clientY;
    isDragging = true;
    
    selBox = document.createElement('div');
    Object.assign(selBox.style, {
      position: 'fixed', border: '2px dashed #007aff', background: 'rgba(0, 122, 255, 0.1)', zIndex: 1000000000,
      left: '0px', top: '0px', width: '0px', height: '0px',
      pointerEvents: 'none', transform: `translate3d(${startX}px, ${startY}px, 0)`, willChange: 'width, height, transform'
    });
    document.body.appendChild(selBox);
    
    window.addEventListener('mousemove', onMove, { passive: true });
    window.addEventListener('mouseup', onUp, { once: true });
  }

  function onMove(e) {
    if (!isDragging || !selBox) return;
    const w = e.clientX - startX;
    const h = e.clientY - startY;
    const x = w < 0 ? e.clientX : startX;
    const y = h < 0 ? e.clientY : startY;
    
    selBox.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    selBox.style.width = Math.abs(w) + 'px';
    selBox.style.height = Math.abs(h) + 'px';
  }

  async function onUp() {
    isDragging = false;
    window.removeEventListener('mousemove', onMove);
    overlay.remove();
    if (!selBox) return;
    const rect = selBox.getBoundingClientRect();
    selBox.remove();

    if(rect.width < 5 || rect.height < 5) return;

    chrome.runtime.sendMessage({ type: 'mindframe-get-screen' }, response => {
        if (!response || !response.dataUrl) return;
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const dpr = window.devicePixelRatio || 1;
            canvas.width = rect.width * dpr; canvas.height = rect.height * dpr;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, rect.left * dpr, rect.top * dpr, rect.width * dpr, rect.height * dpr, 0, 0, canvas.width, canvas.height);
            
            chrome.runtime.sendMessage({
                type: 'mindframe-shot-ready',
                image: canvas.toDataURL('image/png'),
                pageUrl: location.href,
                width: rect.width, height: rect.height
            });
        };
        img.src = response.dataUrl;
    });
  }
  overlay.addEventListener('mousedown', onMouseDown);
  
  chrome.runtime.onMessage.addListener(msg => {
    if (msg.type === 'mindframe-show-menu') {
       const { boards } = msg;
       const menu = document.createElement('div');
       Object.assign(menu.style, {
         position: 'fixed', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
         background: '#fff', padding: '15px', border: '1px solid #ccc', zIndex: 2147483647,
         borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.2)', fontFamily: 'sans-serif'
       });
       
       const title = document.createElement('div');
       title.textContent = "Save to...";
       title.style.fontWeight = "bold"; title.style.textAlign="center"; title.style.marginBottom="10px";
       menu.appendChild(title);

       const addBtn = (txt, cb) => {
           const b = document.createElement('button');
           b.textContent = txt; 
           b.style.display='block'; b.style.width='100%'; b.style.margin='5px 0'; b.style.padding='8px';
           b.style.cursor='pointer'; b.style.border='1px solid #ddd'; b.style.background='#f9f9f9';
           b.onclick = () => { cb(); menu.remove(); };
           menu.appendChild(b);
       };
       
       addBtn('➕ New Mindframe', () => chrome.runtime.sendMessage({type: 'mindframe-create-new-live-shot'}));
       boards.forEach(b => addBtn(b, () => chrome.runtime.sendMessage({type: 'mindframe-add-live-shot', board: b})));
       
       const close = document.createElement('div');
       close.textContent = "Cancel";
       close.style.marginTop="10px"; close.style.fontSize="12px"; close.style.color="#999"; close.style.cursor="pointer"; close.style.textAlign="center";
       close.onclick = () => menu.remove();
       menu.appendChild(close);

       document.body.appendChild(menu);
    }
  });
})();
