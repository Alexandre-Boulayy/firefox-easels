
document.addEventListener("DOMContentLoaded", () => {
  const boardsContainer = document.getElementById("boards");
  const emptyMsg = document.getElementById("empty-msg");

  function renderBoards() {
    chrome.storage.local.get({ boards: {} }, (result) => {
      boardsContainer.innerHTML = "";
      const boardNames = Object.keys(result.boards);
      
      if (boardNames.length === 0) {
        emptyMsg.style.display = "block";
      } else {
        emptyMsg.style.display = "none";
        boardNames.forEach((board) => {
          const row = document.createElement("div");
          row.className = "board-row";
          const link = document.createElement("div");
          link.className = "board-name";
          link.textContent = board;
          
          link.onclick = () => chrome.tabs.create({ url: "mindframe.html?board=" + encodeURIComponent(board) });

          const delBtn = document.createElement("button");
          delBtn.className = "delete-btn";
          delBtn.innerHTML = "&times;";
          
          delBtn.onclick = (e) => {
            e.stopPropagation();
            delete result.boards[board];
            chrome.storage.local.set({ boards: result.boards }, renderBoards);
          };

          row.appendChild(link);
          row.appendChild(delBtn);
          boardsContainer.appendChild(row);
        });
      }
    });
  }
  renderBoards();

  document.getElementById("liveCaptureBtn").addEventListener("click", () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs.length) return;
        // V3 CHANGE: Use chrome.scripting
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            files: ["capture.js"]
        });
        window.close();
      });
  });

  document.getElementById("createBtn").addEventListener("click", () => {
      chrome.storage.local.get({ boards: {} }, (r) => {
          let newTitle = "Untitled";
          let c = 1;
          while (r.boards[newTitle]) newTitle = "Untitled " + c++;
          r.boards[newTitle] = [];
          chrome.storage.local.set({ boards: r.boards }, () => {
              chrome.tabs.create({ url: "mindframe.html?board=" + encodeURIComponent(newTitle) });
              window.close();
          });
      });
  });
});
