
function rebuildContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "create-new-mindframe", title: "➕ Create New Mindframe", contexts: ["all"] });
    chrome.storage.local.get({ boards: {} }, (result) => {
      Object.keys(result.boards).forEach((boardName) => {
        chrome.contextMenus.create({ id: "mindframe-popup-" + boardName, title: "Add to " + boardName, contexts: ["all"] });
      });
    });
  });
}

chrome.runtime.onInstalled.addListener(rebuildContextMenu);
chrome.runtime.onStartup.addListener(rebuildContextMenu);

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const boardKey = info.menuItemId.replace("mindframe-popup-", "");
  const isCreation = info.menuItemId === "create-new-mindframe";

  if (info.mediaType === "image" && info.srcUrl) {
    saveToBoard({
        type: "image", data: info.srcUrl, sourceUrl: info.pageUrl, 
        time: Date.now(), left: "0px", top: "200px" 
    }, boardKey, isCreation);
  } else {
    const mode = isCreation ? "new" : boardKey;
    chrome.storage.local.set({ __pendingCaptureMode: mode }, () => {
        // V3 CHANGE: Use chrome.scripting instead of chrome.tabs.executeScript
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["capture.js"]
        });
    });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'mindframe-get-screen') {
    chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png' }, dataUrl => sendResponse({ dataUrl }));
    return true; 
  }

  if (msg.type === 'mindframe-shot-ready') {
    chrome.storage.local.get({ __pendingCaptureMode: null }, (res) => {
        let w = msg.width || 200;
        let h = msg.height || 150;
        const MAX_WIDTH = 500;
        if (w > MAX_WIDTH) {
            h = (MAX_WIDTH / w) * h;
            w = MAX_WIDTH;
        }

        const item = {
            type: "image", data: msg.image, sourceUrl: msg.pageUrl,
            time: Date.now(), left: "0px", top: "200px",
            width: w + "px", height: h + "px"
        };

        if (res.__pendingCaptureMode) {
             const isNew = res.__pendingCaptureMode === "new";
             saveToBoard(item, isNew ? null : res.__pendingCaptureMode, isNew);
             chrome.storage.local.remove("__pendingCaptureMode");
        } else {
             chrome.storage.local.set({ __mindframePendingShot: item }, () => {
                chrome.storage.local.get({ boards: {} }, r => {
                     chrome.tabs.sendMessage(sender.tab.id, { type: 'mindframe-show-menu', boards: Object.keys(r.boards) });
                });
             });
        }
    });
  }

  if (msg.type === 'mindframe-add-live-shot' || msg.type === 'mindframe-create-new-live-shot') {
     chrome.storage.local.get({ __mindframePendingShot: null }, res => {
         if(res.__mindframePendingShot) {
             const isNew = msg.type === 'mindframe-create-new-live-shot';
             saveToBoard(res.__mindframePendingShot, msg.board, isNew);
             chrome.storage.local.remove("__mindframePendingShot");
         }
     });
  }
});

function saveToBoard(item, boardName, isNew) {
    chrome.storage.local.get({ boards: {} }, (result) => {
        const boards = result.boards;
        if (isNew) {
            let newName = "Untitled";
            let count = 1;
            while (boards[newName]) newName = "Untitled " + count++;
            boards[newName] = [item];
            chrome.storage.local.set({ boards }, () => {
                chrome.tabs.create({ url: chrome.runtime.getURL("mindframe.html?board=" + encodeURIComponent(newName)) });
                rebuildContextMenu();
            });
        } else {
            if (!boards[boardName]) boards[boardName] = [];
            item.left = ((boards[boardName].length % 4) * 240) + "px";
            item.top = (Math.floor(boards[boardName].length / 4) * 240 + 200) + "px";
            boards[boardName].push(item);
            chrome.storage.local.set({ boards }, () => {
                 chrome.tabs.query({}, tabs => tabs.forEach(t => chrome.tabs.sendMessage(t.id, { type: "refresh-board", board: boardName })));
            });
        }
    });
}
