
(() => {

  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
    cursor: 'crosshair', background: 'rgba(0,0,0,0.15)', zIndex: 999999999
  });
  document.body.appendChild(overlay);

  let startX, startY, selBox;
  function onMouseDown(e) {
    startX = e.clientX; startY = e.clientY;
    selBox = document.createElement('div');
    Object.assign(selBox.style, {
      position: 'fixed', border: '2px dashed #fff',
      background: 'rgba(255,255,255,0.3)', zIndex: 1000000000,
      left: startX + 'px', top: startY + 'px'
    });
    document.body.appendChild(selBox);
    overlay.addEventListener('mousemove', onMove);
    overlay.addEventListener('mouseup', onUp, { once: true });
    window.addEventListener('mouseup', onUp, { once: true });
  }

  function onMove(e) {
    const w = e.clientX - startX, h = e.clientY - startY;
    selBox.style.width = Math.abs(w) + 'px';
    selBox.style.height = Math.abs(h) + 'px';
    selBox.style.left = (w < 0 ? e.clientX : startX) + 'px';
    selBox.style.top = (h < 0 ? e.clientY : startY) + 'px';
  }

  async function onUp() {
    overlay.removeEventListener('mousemove', onMove);
    overlay.remove();
    const rect = selBox.getBoundingClientRect();
    selBox.remove();

    let resp;
    try {
      resp = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'easel-get-screen' }, response => {
          if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
          else resolve(response);
        });
      });
    } catch (err) {
      console.error('❌ failed to get screen capture:', err);
      return;
    }
    if (!resp || !resp.dataUrl) {
      console.error('❌ no dataUrl returned from background', resp);
      return;
    }

    const img = new Image();
    img.src = resp.dataUrl;
    await img.decode();

    const canvas = document.createElement('canvas');
    canvas.width = rect.width * (window.devicePixelRatio || 1);
    canvas.height = rect.height * (window.devicePixelRatio || 1);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(
      img,
      rect.left * (window.devicePixelRatio || 1),
      rect.top * (window.devicePixelRatio || 1),
      rect.width * (window.devicePixelRatio || 1),
      rect.height * (window.devicePixelRatio || 1),
      0, 0,
      rect.width * (window.devicePixelRatio || 1),
      rect.height * (window.devicePixelRatio || 1)
    );
    const base64 = canvas.toDataURL('image/png');
    chrome.runtime.sendMessage({
      type: 'easel-shot-ready',
      image: base64,
      pageUrl: location.href,
      boardsRequest: true
    });
  }

  overlay.addEventListener('mousedown', onMouseDown);

  chrome.runtime.onMessage.addListener(msg => {
    if (msg.type === 'easel-show-menu') {
      const { boards } = msg;
      const menu = document.createElement('div');
      Object.assign(menu.style, {
        position: 'fixed', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%)', background: '#fff',
        color: '#000', padding: '10px', border: '1px solid #000',
        zIndex: 1000000001
      });

      // New easel button
      const createBtn = document.createElement('button');
      createBtn.textContent = '+ Create New Easel';
      createBtn.style.display = 'block';
      createBtn.style.margin = '5px 0';
      createBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'easel-create-new-live-shot' });
        menu.remove();
      });
      menu.appendChild(createBtn);

      // Existing boards
      boards.forEach(boardName => {
        const btn = document.createElement('button');
        btn.textContent = boardName;
        btn.style.display = 'block';
        btn.style.margin = '5px 0';
        btn.addEventListener('click', () => {
          chrome.runtime.sendMessage({ type: 'easel-add-live-shot', board: boardName });
          menu.remove(); menu.remove();
        });
        menu.appendChild(btn);
      });

      document.body.appendChild(menu);
    }
  });
})();
