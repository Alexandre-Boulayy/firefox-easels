function rebuildContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "create-new-easel",
      title: "➕ Create New Easel",
      contexts: ["image"]
    });
    chrome.storage.local.get({ boards: {} }, (result) => {
      Object.keys(result.boards).forEach((boardName) => {
        chrome.contextMenus.create({
          id: "easel-popup-" + boardName,
          title: "Add to " + boardName,
          contexts: ["image"]
        });
      });
    });
  });
}

chrome.runtime.onInstalled.addListener(rebuildContextMenu);
chrome.runtime.onStartup.addListener(rebuildContextMenu);

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const boardKey = info.menuItemId.replace("easel-popup-", "");
  const srcUrl = info.srcUrl;
  const pageUrl = info.pageUrl;
  chrome.storage.local.get({ boards: {} }, (result) => {
    const boards = result.boards;
    if (info.menuItemId === "create-new-easel") {
      let newBoardName = "Untitled";
      let count = 1;
      while (boards[newBoardName]) newBoardName = "Untitled " + count++;
      boards[newBoardName] = [{
        data: srcUrl,
        sourceUrl: pageUrl,
        time: Date.now(),
        left: "0px",
        top: "200px"
      }];
      chrome.storage.local.set({ boards }, () => {
        chrome.tabs.create({ url: chrome.runtime.getURL("easel.html?board=" + encodeURIComponent(newBoardName)) });
        rebuildContextMenu();
      });
    } else if (info.menuItemId.startsWith("easel-popup-")) {
      if (!boards[boardKey]) boards[boardKey] = [];
      const index = boards[boardKey].length;
      const col = index % 4;
      const row = Math.floor(index / 4);
      const left = col * 240;
      const top = row * 240 + 200;
      boards[boardKey].push({
        data: srcUrl,
        sourceUrl: pageUrl,
        time: Date.now(),
        left: `${left}px`,
        top: `${top}px`
      });
      chrome.storage.local.set({ boards }, () => {
        chrome.tabs.sendMessage(tab.id, { type: "refresh-board", board: boardKey });
      });
    }
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'easel-get-screen') {
    chrome.tabs.captureVisibleTab(
      sender.tab ? sender.tab.windowId : null,
      { format: 'png' },
      (dataUrl) => {
        const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
        sendResponse({ dataUrl, error: err });
      }
    );
    return true;
  }
  if (msg.type === 'easel-shot-ready' && msg.boardsRequest) {
    chrome.storage.local.set({ __easelPendingShot: { data: msg.image, sourceUrl: msg.pageUrl } }, () => {
      chrome.storage.local.get({ boards: {} }, (result) => {
        const boardNames = Object.keys(result.boards);
        chrome.tabs.sendMessage(sender.tab.id, { type: 'easel-show-menu', boards: boardNames });
      });
    });
  }
});

// === live-shot addition handler ===
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'easel-add-live-shot') {
    chrome.storage.local.get({ boards: {}, __easelPendingShot: null }, (result) => {
      const boards = result.boards;
      const shot = result.__easelPendingShot;
      if (!shot) return;
      if (!boards[msg.board]) boards[msg.board] = [];
      const index = boards[msg.board].length;
      const col = index % 4, row = Math.floor(index / 4);
      const left = col * 240, top = row * 240 + 200;
      boards[msg.board].push({
        data: shot.data,
        sourceUrl: shot.sourceUrl,
        time: Date.now(),
        left: `${left}px`,
        top: `${top}px`
      });
      chrome.storage.local.set({ boards }, () => {
        chrome.storage.local.remove('__easelPendingShot', () => {});
// notify all tabs to refresh this board
        chrome.tabs.query({}, tabs => {
          tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, { type: 'refresh-board', board: msg.board });
          });
        });
      });
    });
  }
});


// === Create new easel from live shot ===
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'easel-create-new-live-shot') {
    chrome.storage.local.get({ boards: {}, __easelPendingShot: null }, result => {
      const boards = result.boards;
      const shot = result.__easelPendingShot;
      if (!shot) return;
      let name = 'Untitled';
      let count = 1;
      while (boards[name]) name = 'Untitled ' + count++;
      boards[name] = [{
        data: shot.data,
        sourceUrl: shot.sourceUrl,
        time: Date.now(),
        left: '0px',
        top: '200px'
      }];
      chrome.storage.local.set({ boards }, () => {
        rebuildContextMenu();
        chrome.tabs.create({ url: chrome.runtime.getURL('easel.html?board=' + encodeURIComponent(name)) });
      });
    });
  }
});
