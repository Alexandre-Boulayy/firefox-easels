
document.addEventListener("DOMContentLoaded", () => {
  // List existing easels
  chrome.storage.local.get({ boards: {} }, (result) => {
    const boardsContainer = document.getElementById("boards");
    if (!boardsContainer) return;
    boardsContainer.innerHTML = "";
    Object.keys(result.boards).forEach((board) => {
      const div = document.createElement("div");
      div.className = "board";
      div.textContent = board;
      div.onclick = () => {
        chrome.tabs.create({ url: "easel.html?board=" + encodeURIComponent(board) });
      };
      boardsContainer.appendChild(div);
    });
  });

  // Capture button
  const captureBtn = document.getElementById("liveCaptureBtn");
  if (captureBtn) {
    captureBtn.addEventListener("click", () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs.length) return;
        const tabId = tabs[0].id;
        chrome.tabs.executeScript(tabId, { file: "capture.js" });
      });
    });
  }
});
