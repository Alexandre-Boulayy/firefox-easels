document.addEventListener("DOMContentLoaded", () => {
  const board = document.getElementById("board");
  let boardTitle = document.getElementById("board-title");
  boardTitle.contentEditable = true;
  if (!boardTitle) {
    boardTitle = document.createElement("h1");
    boardTitle.id = "board-title";
    const zw = document.getElementById("zoom-wrapper") || document.body;
    zw.insertBefore(boardTitle, zw.firstChild);
    boardTitle.contentEditable = true;
  
    boardTitle.textContent = boardParam;
  }

  const urlParams = new URLSearchParams(window.location.search);
  let boardParam = urlParams.get("board") || "Default";

  let isTextMode = false;

  const toolbar = document.createElement("div");
  toolbar.id = "toolbar";
  toolbar.innerHTML = '<button id="textTool" title="Add Text">T</button><button id="darkMode" title="Toggle Dark Mode">🌓</button>';
  toolbar.style.position = "absolute";
  toolbar.style.setProperty("top", "20px", "important");
  toolbar.style.left = "20px";toolbar.style.display = "flex";
toolbar.style.alignItems = "center";
toolbar.style.justifyContent = "center";
toolbar.style.setProperty("gap", "8px");
board.appendChild(toolbar);
  // Dark mode toggle on body
  const darkModeBtn = document.getElementById("darkMode");
  darkModeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    const zoomWrapper = document.getElementById("zoom-wrapper");
    zoomWrapper.classList.toggle("dark");
  });


  function renderItems(items) {
    const existingToolbar = document.getElementById("toolbar");
    board.innerHTML = "";
    if (existingToolbar) board.appendChild(existingToolbar);

    items.forEach((item, index) => {
      const div = document.createElement("div");
            // mark item type for resize control
            if (item.data && (item.data.startsWith('http') || item.data.startsWith('data:'))) {
              div.classList.add('image-item');
            } else {
              div.classList.add('text-item');
            }
            // restore saved size
            if (item.width) div.style.width = item.width;
            if (item.height) div.style.height = item.height;
        const ctrl = document.createElement("div");
        ctrl.className = "item-controls";
      div.className = "item";
      div.classList.add((item.data && (item.data.startsWith('http') || item.data.startsWith('data:'))) ? 'image-item' : 'text-item');
      div.style.left = item.left || "0px";
      div.style.top = item.top || "0px";
      div.setAttribute("data-index", index);

      const deleteBtn = document.createElement("button");
      if (item.data && (item.data.startsWith("http") || item.data.startsWith("data:"))) {
          deleteBtn.className = "delete-btn-image";
        } else {
          deleteBtn.className = "delete-btn-text";
        }
      deleteBtn.textContent = "✕";
      deleteBtn.onclick = () => {
        chrome.storage.local.get({ boards: {} }, (result) => {
          const boards = result.boards;
          boards[boardParam].splice(index, 1);
          chrome.storage.local.set({ boards }, () => {
            loadAndRender(boardParam);
          });
        });
      };

      if (item.data && (item.data.startsWith("http") || item.data.startsWith("data:"))) {
        const img = document.createElement("img");
        img.src = item.data;
        img.alt = "Saved image";
        img.draggable = false;
        img.addEventListener("dragstart", e => e.preventDefault());
        div.appendChild(img);
        img.style.width = "100%";
        img.style.height = "100%";
        img.style.objectFit = "contain";


        if (item.sourceUrl) {
          const visitBtn = document.createElement("button");
          visitBtn.className = "visit-link";
          visitBtn.textContent = "→";
          visitBtn.onclick = () => window.open(item.sourceUrl, "_blank");
            ctrl.appendChild(visitBtn);
          // reload button
          }
      } 

        ctrl.appendChild(deleteBtn);
        div.appendChild(ctrl);
              // observe resize to save new size
              if (div.classList.contains('image-item')) {
                const ro = new ResizeObserver(entries => {
                  entries.forEach(entry => {
                    const w = entry.target.style.width;
                    const h = entry.target.style.height;
                    chrome.storage.local.get({ boards: {} }, result => {
                      const boards = result.boards;
                      boards[boardParam][index].width = w;
                      boards[boardParam][index].height = h;
                      chrome.storage.local.set({ boards });
                    });
                  });
                });
                ro.observe(div);
              }
      board.appendChild(div);

      let isDragging = false, offsetX = 0, offsetY = 0;

      div.addEventListener("mousedown", (e) => {
        const threshold = 10;
      const rect = div.getBoundingClientRect();
      if (e.clientX > rect.right - threshold && e.clientY > rect.bottom - threshold) return;
      if (e.target.classList.contains("visit-link") || e.target.classList.contains("delete-btn")) return;
        isDragging = true;
        offsetX = e.clientX - div.offsetLeft;
        offsetY = e.clientY - div.offsetTop;
        div.classList.add("dragging");
      });

      document.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        div.style.left = (e.clientX - offsetX) + "px";
        div.style.top = (e.clientY - offsetY) + "px";
      });

      document.addEventListener("mouseup", () => {
        if (!isDragging) return;
        chrome.storage.local.get({ boards: {} }, (result) => {
          const boards = result.boards;
          boards[boardParam][index].left = div.style.left;
          boards[boardParam][index].top = div.style.top;
          chrome.storage.local.set({ boards });
        });
        isDragging = false;
        div.classList.remove("dragging");
      });
    });

    document.body.style.opacity = 1;
  }

  function loadAndRender(boardName) {
    setTimeout(() => {
      chrome.storage.local.get({ boards: {} }, (result) => {
        const items = result.boards[boardName] || [];
        renderItems(items);
      });
    }, 100);
  }

  loadAndRender(boardParam);

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "refresh-board" && message.board === boardParam) {
      loadAndRender(boardParam);
    }
  });

  boardTitle.textContent = boardParam;
  document.title = boardParam;
  boardTitle.contentEditable = true;
  
  let isTitleDragging = false, offsetTitleX = 0, offsetTitleY = 0;

  boardTitle.style.position = "absolute";
  boardTitle.style.cursor = "move";
  boardTitle.setAttribute("draggable","false");
  boardTitle.style.display = "block";
  boardTitle.style.left = "50%";
  boardTitle.style.top = "10px";
  boardTitle.style.transform = "translateX(-50%)";

  boardTitle.addEventListener("mousedown", (e) => {
    if (!e.altKey) return;
    e.preventDefault();
    let startX = e.clientX - boardTitle.offsetLeft;
    let startY = e.clientY - boardTitle.offsetTop;
    const moveHandler = (ev) => {
      boardTitle.style.left = (ev.clientX - startX) + "px";
      boardTitle.style.top = (ev.clientY - startY) + "px";
      boardTitle.style.transform = "none";
    };
    const upHandler = () => {
      document.removeEventListener("mousemove", moveHandler);
      document.removeEventListener("mouseup", upHandler);
    };
    document.addEventListener("mousemove", moveHandler);
    document.addEventListener("mouseup", upHandler);
  });
  boardTitle.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      boardTitle.blur();
    }
  });

  document.getElementById("textTool").addEventListener("click", () => {
    isTextMode = !isTextMode;
    document.getElementById("textTool").classList.toggle("active", isTextMode);
  });
  board.addEventListener("click", (e) => {
    if (!isTextMode || e.target !== board) return;
    chrome.storage.local.get({ boards: {} }, (result) => {
      const boards = result.boards;
      if (!boards[boardParam]) boards[boardParam] = [];
      boards[boardParam].push({
        data: "Double-click to edit",
        left: `${e.clientX}px`,
        top: `${e.clientY}px`,
        time: Date.now()
      });
      chrome.storage.local.set({ boards }, () => {
        loadAndRender(boardParam);
        isTextMode = false;
        document.getElementById("textTool").classList.remove("active");
      });
    });
  });
});

  let scale = 1;
  document.addEventListener("wheel", (e) => {
    if (!e.ctrlKey) return;
    e.preventDefault();
    const zoomWrapper = document.getElementById("zoom-wrapper");
    scale += e.deltaY * -0.001;
    scale = Math.min(Math.max(0.2, scale), 4);
    zoomWrapper.style.transform = `scale(${scale})`;
  }, { passive: false });

  document.getElementById("darkMode").addEventListener("click", () => {
    const zoomWrapper = document.getElementById("zoom-wrapper");
    zoomWrapper.classList.toggle("dark");
  });